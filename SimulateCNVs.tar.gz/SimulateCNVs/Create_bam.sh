#!/bin/bash

REF="control"
PATH_TO_PICARD=$1
PATH_TO_GATK=$2
FILE=$3
OUT_DIR=$4
TMP_DIR=$5
pp=$6

cd $TMP_DIR

if [ $pp == "p" ]
then
	bwa mem -t 5 ${OUT_DIR}/${REF}.fa ${OUT_DIR}/${FILE}.1.fq ${OUT_DIR}/${FILE}.2.fq > ${FILE}.sam
else
	bwa mem -t 5 ${OUT_DIR}/${REF}.fa ${OUT_DIR}/${FILE}.fq > ${FILE}.sam
fi

samtools view -Sb ${FILE}.sam > ${FILE}.bam
samtools sort -o ${FILE}.sr.bam ${FILE}.bam 
samtools index ${FILE}.sr.bam

samtools rmdup ${FILE}.sr.bam ${FILE}.sr.rm.bam
samtools index ${FILE}.sr.rm.bam

java -jar ${PATH_TO_PICARD}/picard.jar AddOrReplaceReadGroups \
    I= ${FILE}.sr.rm.bam \
    O= ${FILE}.sr.rm.hd.bam \
    SORT_ORDER=coordinate \
    RGID=foo \
    RGLB=bar \
    RGPL=illumina \
    RGSM=Sample1 \
    RGPU=L001 \
    CREATE_INDEX=True

java -jar ${PATH_TO_GATK}/GenomeAnalysisTK.jar -T RealignerTargetCreator \
-R ${OUT_DIR}/${REF}.fa -I ${FILE}.sr.rm.hd.bam -o ${FILE}_IndelRealigner.intervals

java -jar ${PATH_TO_GATK}/GenomeAnalysisTK.jar -T IndelRealigner \
-R ${OUT_DIR}/${REF}.fa -I ${FILE}.sr.rm.hd.bam -targetIntervals ${FILE}_IndelRealigner.intervals \
-o ${FILE}.sr.rm.hd.re.bam

cp ${FILE}.sr.rm.hd.re.bam ${OUT_DIR}/${FILE}.final.bam
cp ${FILE}.sr.rm.hd.re.bai ${OUT_DIR}/${FILE}.final.bam.bai
